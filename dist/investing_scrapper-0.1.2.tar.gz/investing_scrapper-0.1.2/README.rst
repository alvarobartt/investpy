Investing Scrapper of continuous Spanish stock market
=====================================================

Since `Investing <https://es.investing.com/>`_ does not have an API to retrieve
historical data of the continuous spanish stock market, I decided to create a scrapper
to retrieve that information.

Mainly I decided to create this scrapper in order to get the exact data I want
for my Final Degree Project in the University of Salamanca.

So, to sum up, this is not a professional scrapper, it's just a solution to solve my problem,
but I will continue updating it, since this is just the pre-alpha version of it. So you can 
retrieve more information indexed in Investing.

Disclaimer: this is just for personal use, I am not related at all with Investing or
any related company. This is just a piece of a research project made by me.
